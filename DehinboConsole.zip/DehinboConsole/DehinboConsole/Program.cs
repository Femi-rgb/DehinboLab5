﻿namespace DehinboConsole
{
    //DEHINBO ABDULWAHAB
    // SEPT 17
    // MY First Console App


    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.Write("please enter your name here -> "); 

            string myName = Console.ReadLine();
            Console.WriteLine("The name entered was " + myName);


            Console.WriteLine("I am From Lagos,Nigeria");
            Console.WriteLine("My Interets are GAMING AND SPORTS LIKE BASKETBALL AND FOOTBALL");
            Console.ReadKey();

        }
    }
}
