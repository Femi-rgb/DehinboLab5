﻿// Name: Dehinbo Abdulwahab
// Date: 22nd November 2025
// Description: Lab 4 – Property Tax Program using arrays, loops, validation, methods

using System;
using System.Drawing;
using System.Xml.Linq;

namespace DehinboLab4
{
    public partial class Form1 : Form
    {
        // Class-level Variable
        private const int SIZE = 5;
        private const string MYNAME = "Dehinbo Abdulwahab";

        // Class-level Array
        private double[] taxList = new double[SIZE];

        // Tracks next available index
        private int index = 0;
        public Form1()
        {
            InitializeComponent();
            this.CenterToScreen();

            lblNumber.Text = (index + 1).ToString("D1");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        // Method to Clear Outputs 
        private void ClearOutputs()
        {
            lblTax.Text = "";
            lblAverage.Text = "";
        }

        // Method to  Display Entries
        private void DisplayEntries()
        {
            lblEntries.Text = ""; // clear
            for (int i = 0; i < index; i++)
            {
                lblEntries.Text += $"{taxList[i].ToString("C2")}\n";
            }
        }

        // Method to Compute average
        private double ComputeAverage()
        {
            if (index == 0)
                return 0;

            double sum = 0;
            for (int i = 0; i < index; i++)
            {
                sum += taxList[i];
            }

            return sum / index;
        }
        //Calculating Button
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            const double MINVALUE = 50000;
            const double MAXVALUE = 1500000;
            const double RATE_PRIMARY = 0.01714;
            const double RATE_NONPRIMARY = 0.02275;
            const double RATE_COMMERCIAL = 0.027518;


            ClearOutputs();

            // Validate Property Value 
            if (!double.TryParse(txtValue.Text, out double propertyValue))
            {
                MessageBox.Show("Value must be a valid number!", MYNAME);
                txtValue.SelectAll();
                txtValue.Focus();
                return;
            }

            if (propertyValue < MINVALUE || propertyValue > MAXVALUE)
            {
                MessageBox.Show("Value must be between $50,000 and $1,500,000.", MYNAME);
                txtValue.SelectAll();
                txtValue.Focus();
                return;
            }

            // Determine property type & rate (switch)

            double rate = 0;
            string       type = "";

            if (rdoPrimary.Checked)
                type = "Primary";
            else if (rdoNonPrimary.Checked)
                type = "NonPrimary";
            else if (rdoCommercial.Checked)
                type = "Commercial";
            else
            {
                MessageBox.Show("Select a property type!", MYNAME);
                return;
            }

            switch (type)
            {
                case "Primary":
                    rate = RATE_PRIMARY;
                    break;

                case "NonPrimary":
                    rate = RATE_NONPRIMARY;
                    break;

                case "Commercial":
                    rate = RATE_COMMERCIAL;
                    break;
            }


            // Calculate property tax

            double tax = propertyValue * rate;
            lblTax.Text = tax.ToString("C2");


            // Display transaction number (index + 1)

            lblNumber.Text = (index + 1).ToString("D1");


            // Store in array

            if (index < SIZE)
            {
                taxList[index] = tax;
                index++;
            }
            else
            {
                MessageBox.Show("Maximum entries reached!", MYNAME);
                return;
            }


            // Update Entries and Average

            DisplayEntries();
            lblAverage.Text = ComputeAverage().ToString("C2");


            // Disable Calculate until Reset

            btnCalculate.Enabled = false;
        }



        // RESET button
        private void btnReset_Click(object sender, EventArgs e)
        {
            // If SIZE entries are done then restart
            if (index == SIZE)
            {
                DialogResult selection =
                    MessageBox.Show("Maximum entries reached. Restart?", MYNAME,
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (selection == DialogResult.Yes)
                {
                    // Clear array
                    for (int i = 0; i < SIZE; i++)
                    {
                        taxList[i] = 0;
                    }

                    index = 0;
                    lblEntries.Text = "";
                    ClearOutputs();
                }
                else
                {
                    MessageBox.Show("Closing program...", MYNAME);
                    this.Close();
                    return;
                }
            }

            
            // Reset
            
            btnCalculate.Enabled = true;

            txtValue.Text = "";
            rdoPrimary.Checked = false;
            rdoNonPrimary.Checked = false;
            rdoCommercial.Checked = false;

            ClearOutputs();
            txtValue.Focus();
        }
    }
}
