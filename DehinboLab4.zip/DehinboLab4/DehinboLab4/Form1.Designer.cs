﻿namespace DehinboLab4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtValue = new TextBox();
            groupBox1 = new GroupBox();
            rdoCommercial = new RadioButton();
            rdoNonPrimary = new RadioButton();
            rdoPrimary = new RadioButton();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            lblEntries = new Label();
            btnCalculate = new Button();
            btnReset = new Button();
            lblTax = new Label();
            lblAverage = new Label();
            lblNumber = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(13, 16);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(103, 29);
            label1.TabIndex = 0;
            label1.Text = "Number:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(13, 61);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(169, 29);
            label2.TabIndex = 1;
            label2.Text = "Property Value:";
            // 
            // txtValue
            // 
            txtValue.Font = new Font("Calibri", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtValue.Location = new Point(195, 58);
            txtValue.Margin = new Padding(4);
            txtValue.Name = "txtValue";
            txtValue.Size = new Size(194, 37);
            txtValue.TabIndex = 3;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdoCommercial);
            groupBox1.Controls.Add(rdoNonPrimary);
            groupBox1.Controls.Add(rdoPrimary);
            groupBox1.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(13, 120);
            groupBox1.Margin = new Padding(4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4);
            groupBox1.Size = new Size(390, 192);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Property Type";
            // 
            // rdoCommercial
            // 
            rdoCommercial.AutoSize = true;
            rdoCommercial.Location = new Point(38, 136);
            rdoCommercial.Margin = new Padding(4);
            rdoCommercial.Name = "rdoCommercial";
            rdoCommercial.Size = new Size(159, 33);
            rdoCommercial.TabIndex = 2;
            rdoCommercial.TabStop = true;
            rdoCommercial.Text = "Commercial";
            rdoCommercial.UseVisualStyleBackColor = true;
            // 
            // rdoNonPrimary
            // 
            rdoNonPrimary.AutoSize = true;
            rdoNonPrimary.Location = new Point(38, 91);
            rdoNonPrimary.Margin = new Padding(4);
            rdoNonPrimary.Name = "rdoNonPrimary";
            rdoNonPrimary.Size = new Size(274, 33);
            rdoNonPrimary.TabIndex = 1;
            rdoNonPrimary.TabStop = true;
            rdoNonPrimary.Text = "Non-Primary Residence";
            rdoNonPrimary.UseVisualStyleBackColor = true;
            // 
            // rdoPrimary
            // 
            rdoPrimary.AutoSize = true;
            rdoPrimary.Location = new Point(38, 46);
            rdoPrimary.Margin = new Padding(4);
            rdoPrimary.Name = "rdoPrimary";
            rdoPrimary.Size = new Size(225, 33);
            rdoPrimary.TabIndex = 0;
            rdoPrimary.TabStop = true;
            rdoPrimary.Text = "Primary Residence";
            rdoPrimary.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(13, 334);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(146, 29);
            label3.TabIndex = 5;
            label3.Text = "Property Tax:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(13, 392);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(100, 29);
            label4.TabIndex = 6;
            label4.Text = "Average:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(423, -2);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(83, 29);
            label5.TabIndex = 9;
            label5.Text = "Entries";
            // 
            // lblEntries
            // 
            lblEntries.BackColor = Color.Pink;
            lblEntries.Font = new Font("Courier New", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEntries.Location = new Point(423, 21);
            lblEntries.Margin = new Padding(4, 0, 4, 0);
            lblEntries.Name = "lblEntries";
            lblEntries.Size = new Size(409, 480);
            lblEntries.TabIndex = 10;
            // 
            // btnCalculate
            // 
            btnCalculate.AutoSize = true;
            btnCalculate.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalculate.Location = new Point(13, 445);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(121, 56);
            btnCalculate.TabIndex = 11;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // btnReset
            // 
            btnReset.AutoSize = true;
            btnReset.Font = new Font("Calibri", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReset.Location = new Point(195, 445);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(130, 56);
            btnReset.TabIndex = 12;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // lblTax
            // 
            lblTax.BackColor = Color.Pink;
            lblTax.BorderStyle = BorderStyle.Fixed3D;
            lblTax.Location = new Point(195, 330);
            lblTax.Name = "lblTax";
            lblTax.Size = new Size(194, 38);
            lblTax.TabIndex = 13;
            // 
            // lblAverage
            // 
            lblAverage.BackColor = Color.Pink;
            lblAverage.BorderStyle = BorderStyle.Fixed3D;
            lblAverage.Location = new Point(195, 383);
            lblAverage.Name = "lblAverage";
            lblAverage.Size = new Size(194, 38);
            lblAverage.TabIndex = 14;
            // 
            // lblNumber
            // 
            lblNumber.BackColor = Color.Pink;
            lblNumber.BorderStyle = BorderStyle.Fixed3D;
            lblNumber.Location = new Point(195, 7);
            lblNumber.Name = "lblNumber";
            lblNumber.Size = new Size(194, 38);
            lblNumber.TabIndex = 15;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(838, 507);
            Controls.Add(lblNumber);
            Controls.Add(lblAverage);
            Controls.Add(lblTax);
            Controls.Add(btnReset);
            Controls.Add(btnCalculate);
            Controls.Add(lblEntries);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(groupBox1);
            Controls.Add(txtValue);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Tax Program";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtValue;
        private GroupBox groupBox1;
        private RadioButton rdoCommercial;
        private RadioButton rdoNonPrimary;
        private RadioButton rdoPrimary;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label lblEntries;
        private Button btnCalculate;
        private Button btnReset;
        private Label lblTax;
        private Label lblAverage;
        private Label lblNumber;
    }
}
